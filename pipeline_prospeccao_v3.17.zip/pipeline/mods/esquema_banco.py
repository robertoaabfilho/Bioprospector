"""
esquema_banco.py - Esquema do banco relacional (v3.17), em um lugar só.

Daqui saem: a ordem das colunas de cada CSV da pasta banco/, o dicionário de
dados (banco/dicionario_dados.csv), o esquema legível (banco/ESQUEMA.md) e o
descritor Frictionless Data (banco/datapackage.json), com chaves primárias e
estrangeiras.

Todas as tabelas de dados de compostos se ligam pelo InChIKey canônico
(compostos.inchikey). As tabelas de organismos se ligam pelo nome científico
(organismos.nome_cientifico), e a origem biológica liga as duas.
"""

import json

# (coluna, tipo, descrição). Tipos do Table Schema: string, integer, number, boolean
T = "string"
I = "integer"
N = "number"
B = "boolean"

TABELAS = {
    "compostos": {
        "descricao": "Identidade química: um composto por InChIKey canônico (deduplicado entre "
                     "todas as bases), com identificadores normalizados pelo PubChem e "
                     "classificação estrutural ClassyFire.",
        "chave": ["inchikey"],
        "colunas": [
            ("inchikey", T, "InChIKey canônico (identificador universal; chave de todo o banco)"),
            ("inchikey_conectividade", T, "1º bloco do InChIKey (14 caracteres): esqueleto sem estereoquímica"),
            ("nome_preferido", T, "título do PubChem; sem ele, o nome mais frequente nas bases"),
            ("nome_iupac", T, "nome IUPAC (PubChem)"),
            ("pubchem_cid", I, "PubChem CID do InChIKey canônico"),
            ("status_pubchem", T, "confirmado | ausente no PubChem | PubChem não consultado"),
            ("inchi", T, "InChI padrão (PubChem)"),
            ("smiles_isomerico", T, "SMILES com estereoquímica (PubChem; sem ele, o da base de maior prioridade)"),
            ("smiles_canonico", T, "SMILES canônico calculado pelo RDKit a partir de smiles_isomerico"),
            ("smiles_conectividade", T, "SMILES sem estereoquímica (PubChem)"),
            ("fonte_estrutura", T, "de onde veio a estrutura: PubChem ou a base"),
            ("formula_molecular", T, "fórmula molecular (PubChem; sem ela, calculada pelo RDKit)"),
            ("massa_molecular", N, "massa molecular média (g/mol, PubChem)"),
            ("massa_exata", N, "massa monoisotópica (Da, PubChem)"),
            ("carga", I, "carga formal líquida (PubChem)"),
            ("xlogp_pubchem", N, "XLogP3 (PubChem)"),
            ("tpsa_pubchem", N, "área polar topológica (Å², PubChem)"),
            ("complexidade_pubchem", N, "complexidade de Bertz/Hendrickson (PubChem)"),
            ("inchikey_parental", T, "InChIKey da forma parental (sem contraíon, neutralizada; RDKit)"),
            ("forma_parental_diferente", B, "true = o registro é sal ou forma carregada"),
            ("classyfire_kingdom", T, "ClassyFire: reino"),
            ("classyfire_superclass", T, "ClassyFire: superclasse"),
            ("classyfire_class", T, "ClassyFire: classe"),
            ("classyfire_subclass", T, "ClassyFire: subclasse"),
            ("classyfire_direct_parent", T, "ClassyFire: pai direto"),
            ("classyfire_framework", T, "ClassyFire: arcabouço molecular"),
            ("classyfire_fonte", T, "ClassyFire (API) ou COCONUT (ClassyFire pré-calculado)"),
            ("np_classifier_pathway", T, "NPClassifier: via biossintética (COCONUT)"),
            ("np_classifier_superclass", T, "NPClassifier: superclasse (COCONUT)"),
            ("np_classifier_class", T, "NPClassifier: classe (COCONUT)"),
            ("bases", T, "bases em que o composto aparece (separadas por '; ')"),
            ("n_bases", I, "número de bases distintas"),
            ("ids_nas_bases", T, "identificadores do composto em cada base"),
            ("n_ocorrencias", I, "registros de base x organismo (linhas em fontes.csv)"),
            ("n_plantas", I, "organismos produtores distintos"),
            ("n_sinonimos", I, "sinônimos registrados"),
            ("n_conflitos", I, "conflitos entre bases envolvendo o composto"),
            ("tipos_conflito", T, "tipos de conflito (ver conflitos.csv)"),
            ("n_bioatividades", I, "registros em bioatividade.csv"),
            ("n_bioatividades_quantitativas", I, "registros com valor numérico medido"),
            ("n_vias", I, "registros em vias_metabolicas.csv"),
            ("n_espectros", I, "registros experimentais/compilados em dados_espectrais.csv"),
            ("tem_admet", B, "true = perfil calculado em perfil_admet.csv"),
        ],
    },
    "fontes": {
        "descricao": "Rastreabilidade: cada registro de cada base (base x composto x organismo), "
                     "com o que AQUELA base informa e como se chegou ao InChIKey canônico.",
        "chave": ["id_ocorrencia"],
        "estrangeiras": [("inchikey", "compostos", "inchikey"),
                         ("nome_cientifico", "organismos", "nome_cientifico")],
        "colunas": [
            ("id_ocorrencia", T, "identificador do registro (OC0000001...)"),
            ("inchikey", T, "InChIKey canônico (vazio = registro sem estrutura)"),
            ("base", T, "COCONUT | NPASS | LOTUS | FOODB | DUKE"),
            ("id_na_base", T, "identificador do composto na base"),
            ("url_registro", T, "página do composto na base, quando existe"),
            ("nome_na_base", T, "nome do composto como está na base"),
            ("inchikey_declarado", T, "InChIKey informado pela base (válido)"),
            ("inchikey_calculado", T, "InChIKey calculado pelo RDKit do SMILES da base"),
            ("metodo_identificacao", T, "regra que definiu o InChIKey canônico"),
            ("smiles_na_base", T, "SMILES informado pela base"),
            ("smiles_valido", B, "o RDKit leu o SMILES da base"),
            ("pubchem_cid_na_base", T, "CID informado pela base"),
            ("organismo_na_base", T, "nome do organismo como casado na base"),
            ("nome_cientifico", T, "organismo produtor (linha de plantas.csv)"),
            ("atividade_na_base", T, "atividade/alvo informado pela base (NPASS, Dr. Duke)"),
            ("parte_planta", T, "parte da planta (Dr. Duke)"),
            ("teor", T, "teor relatado (Dr. Duke em ppm; FooDB)"),
            ("referencia", T, "referência bibliográfica do par (DOI do LOTUS)"),
        ],
    },
    "sinonimos": {
        "descricao": "Sinônimos e nomes do composto (PubChem e nomes usados em cada base).",
        "chave": ["inchikey", "sinonimo", "fonte"],
        "estrangeiras": [("inchikey", "compostos", "inchikey")],
        "colunas": [
            ("inchikey", T, "InChIKey canônico"),
            ("sinonimo", T, "nome"),
            ("tipo", T, "sinônimo | nome IUPAC | nome na base"),
            ("fonte", T, "PubChem ou a base"),
        ],
    },
    "organismos": {
        "descricao": "Organismos produtores (linhas de plantas.csv que têm ao menos um composto), "
                     "com taxonomia e distribuição resumida.",
        "chave": ["nome_cientifico"],
        "colunas": [
            ("nome_cientifico", T, "nome da linha em plantas.csv"),
            ("nome_aceito", T, "nome aceito (Flora do Brasil, WFO, WCVP ou GBIF)"),
            ("categoria_taxonomica", T, "SPECIES, GENUS..."),
            ("reino", T, ""), ("filo", T, ""), ("classe", T, ""), ("ordem", T, ""),
            ("familia", T, ""),
            ("nome_popular_pt", T, "nome popular"),
            ("speciesKey", T, "chave GBIF"),
            ("estados_br", T, "UFs (siglas)"),
            ("dominios_br", T, "domínios fitogeográficos"),
            ("endemismo_br", T, "endêmica do Brasil / não endêmica"),
            ("origem_br", T, "nativa / exótica"),
            ("fonte_distribuicao", T, "Flora e Funga do Brasil ou GBIF"),
            ("n_compostos", I, "compostos (InChIKey) atribuídos ao organismo"),
        ],
    },
    "origem_biologica": {
        "descricao": "Composto x organismo produtor (uma linha por par), com as bases que o "
                     "registram e os metadados de cada uma.",
        "chave": ["inchikey", "nome_cientifico"],
        "estrangeiras": [("inchikey", "compostos", "inchikey"),
                         ("nome_cientifico", "organismos", "nome_cientifico")],
        "colunas": [
            ("inchikey", T, "InChIKey canônico"),
            ("nome_cientifico", T, "organismo produtor"),
            ("familia", T, "família do organismo"),
            ("bases", T, "bases que registram o par"),
            ("n_bases", I, "número de bases"),
            ("nomes_organismo_nas_bases", T, "nomes do organismo como aparecem nas bases"),
            ("parte_planta", T, "parte da planta (Dr. Duke)"),
            ("teor", T, "teor (Dr. Duke, FooDB)"),
            ("referencias", T, "referências (LOTUS)"),
            ("ids_ocorrencias", T, "registros de fontes.csv que sustentam o par"),
        ],
    },
    "distribuicao_geografica": {
        "descricao": "Distribuição geográfica do composto pelos organismos que o produzem: "
                     "composto x organismo x UF (Flora e Funga do Brasil; GBIF como 2ª camada).",
        "chave": ["inchikey", "nome_cientifico", "uf"],
        "estrangeiras": [("inchikey", "compostos", "inchikey"),
                         ("nome_cientifico", "organismos", "nome_cientifico")],
        "colunas": [
            ("inchikey", T, "InChIKey canônico"),
            ("nome_cientifico", T, "organismo produtor"),
            ("uf", T, "sigla da UF; vazio = distribuição desconhecida"),
            ("dominios_br", T, "domínios do organismo"),
            ("endemismo_br", T, ""), ("origem_br", T, ""),
            ("fonte_distribuicao", T, "Flora e Funga do Brasil ou GBIF"),
            ("registros_gbif_uf", I, "nº de registros GBIF na UF (só quando a fonte é o GBIF)"),
        ],
    },
    "bioatividade": {
        "descricao": "Bioatividade: medidas quantitativas (ChEMBL, NPASS) e relatos qualitativos "
                     "em artigos lidos pelo modelo (PubMed).",
        "chave": ["id_bioatividade"],
        "estrangeiras": [("inchikey", "compostos", "inchikey")],
        "colunas": [
            ("id_bioatividade", T, "identificador (BA0000001...)"),
            ("inchikey", T, "InChIKey canônico"),
            ("fonte", T, "ChEMBL | NPASS | PubMed"),
            ("natureza", T, "quantitativa | qualitativa"),
            ("correspondencia", T, "exata | estereoisômero | prevista (similaridade) | -"),
            ("molecula_ensaiada", T, "ID da molécula ensaiada na fonte (ChEMBL/NPASS)"),
            ("atividade_input", T, "atividade do input.txt a que o registro foi ligado"),
            ("alvo", T, "alvo molecular, célula ou organismo"),
            ("organismo_alvo", T, "organismo do alvo"),
            ("tipo_ensaio", T, "B, F, A, T... (ChEMBL) ou tipo de estudo (PubMed)"),
            ("descricao_ensaio", T, "descrição do ensaio ou justificativa do modelo"),
            ("tipo_medida", T, "IC50, Ki, MIC, Inhibition..."),
            ("relacao", T, "=, <, >, <=, >="),
            ("valor", N, "valor numérico"),
            ("unidade", T, "unidade do valor"),
            ("pvalor", N, "-log10(molar) para IC50/EC50/Ki/Kd... em unidade molar (pChEMBL quando existe)"),
            ("ativo", B, "pvalor >= pchembl_minimo do input.txt, ou marcado como ativo pela fonte"),
            ("pmid", T, "PMID"), ("doi", T, "DOI"), ("ano", I, "ano da publicação"),
            ("id_registro_fonte", T, "documento/registro na fonte"),
        ],
    },
    "vias_metabolicas": {
        "descricao": "Vias metabólicas e de sinalização associadas ao composto (PubChem: "
                     "Reactome, WikiPathways, KEGG, PlantCyc, PathBank...) e a via biossintética "
                     "prevista pelo NPClassifier.",
        "chave": ["inchikey", "fonte", "via_id"],
        "estrangeiras": [("inchikey", "compostos", "inchikey")],
        "colunas": [
            ("inchikey", T, "InChIKey canônico"),
            ("tipo", T, "via (base de vias) | via biossintética (NPClassifier)"),
            ("via_id", T, "identificador da via na fonte"),
            ("via_nome", T, "nome da via"),
            ("fonte", T, "fonte da via"),
            ("categoria", T, "categoria da via"),
            ("organismo", T, "organismo da via"),
            ("url", T, "link"),
        ],
    },
    "dados_espectrais": {
        "descricao": "Dados espectrais: registros compilados no PubChem (MS, MS/MS, GC-MS, "
                     "LC-MS, RMN, IV, UV) e m/z teóricos dos adutos mais comuns (RDKit).",
        "chave": ["id_espectro"],
        "estrangeiras": [("inchikey", "compostos", "inchikey")],
        "colunas": [
            ("id_espectro", T, "identificador (ES0000001...)"),
            ("inchikey", T, "InChIKey canônico"),
            ("origem", T, "experimental (PubChem) | teórico (RDKit)"),
            ("tipo", T, "Mass Spectrometry, NMR Spectra, IR Spectra, UV Spectra..."),
            ("subtipo", T, "GC-MS, MS-MS, 1D NMR, [M+H]+ ..."),
            ("valor", N, "m/z teórico (só origem teórica)"),
            ("descricao", T, "picos, instrumento, condições (texto do PubChem)"),
            ("fonte", T, "depositante (MassBank, HMDB, SpectraBase, NIST...)"),
            ("id_fonte", T, "identificador no depositante"),
            ("url", T, "link"),
        ],
    },
    "perfil_admet": {
        "descricao": "Drogabilidade e perfil ADMET básico calculados localmente (RDKit, módulo "
                     "quimio.py) para todo composto com SMILES canônico. São PREVISÕES por regra, "
                     "não medidas.",
        "chave": ["inchikey"],
        "estrangeiras": [("inchikey", "compostos", "inchikey")],
        "colunas": [
            ("inchikey", T, "InChIKey canônico"),
            ("smiles_canonico", T, "SMILES usado no cálculo"),
            ("status_admet", T, "calculado | SMILES inválido"),
            ("massa_molecular_rdkit", N, "massa molecular (g/mol)"),
            ("massa_monoisotopica_rdkit", N, "massa monoisotópica (Da)"),
            ("logp_crippen", N, "logP de Wildman-Crippen"),
            ("refratividade_molar", N, "refratividade molar (Crippen)"),
            ("tpsa", N, "área polar topológica (Å², Ertl)"),
            ("doadores_h", I, "doadores de ligação de H (Lipinski)"),
            ("aceptores_h", I, "aceptores de ligação de H (Lipinski)"),
            ("ligacoes_rotaveis", I, "ligações rotáveis"),
            ("aneis", I, "anéis"), ("aneis_aromaticos", I, "anéis aromáticos"),
            ("atomos_pesados", I, "átomos pesados"),
            ("fracao_csp3", N, "fração de carbonos sp3"),
            ("carga_formal", I, "carga formal"),
            ("centros_estereo", I, "centros estereogênicos (inclusive não atribuídos)"),
            ("qed", N, "Quantitative Estimate of Drug-likeness (Bickerton 2012), 0-1"),
            ("violacoes_lipinski", I, "violações da regra dos 5"),
            ("lipinski_ok", B, "<= 1 violação"),
            ("veber_ok", B, "rotáveis <= 10 e TPSA <= 140"),
            ("ghose_ok", B, "filtro de Ghose"),
            ("egan_ok", B, "filtro de Egan"),
            ("muegge_ok", B, "filtro de Muegge"),
            ("absorcao_gi_provavel", B, "absorção gastrointestinal provável (BOILED-Egg simplificado)"),
            ("permeacao_bhe_provavel", B, "permeação da barreira hematoencefálica provável (BOILED-Egg simplificado)"),
            ("alertas_pains", T, "subestruturas PAINS (interferência em ensaios)"),
            ("alertas_brenk", T, "subestruturas indesejáveis/tóxicas (Brenk)"),
            ("metodo", T, "ferramenta e versão"),
        ],
    },
    "conflitos": {
        "descricao": "Conflitos detectados entre as bases (e entre bases e PubChem/ClassyFire), "
                     "com a resolução adotada. Um conflito com vários compostos tem uma linha por "
                     "InChIKey.",
        "chave": ["id_conflito", "inchikey"],
        "estrangeiras": [("inchikey", "compostos", "inchikey")],
        "colunas": [
            ("id_conflito", T, "identificador (CF000001...)"),
            ("inchikey", T, "InChIKey canônico envolvido"),
            ("tipo_conflito", T, "ver ESQUEMA.md"),
            ("severidade", T, "alta | média | baixa | informativa"),
            ("campo", T, "campo em conflito"),
            ("bases_envolvidas", T, "bases"),
            ("valores", T, "valores divergentes"),
            ("ids_ocorrencias", T, "registros de fontes.csv envolvidos"),
            ("resolucao", T, "decisão tomada pelo pipeline"),
        ],
    },
    "mapa_inchikey": {
        "descricao": "De-para dos InChIKeys de origem (declarados pelas bases ou calculados dos "
                     "SMILES delas) para o canônico.",
        "chave": ["inchikey_origem", "inchikey_canonico", "origem"],
        "estrangeiras": [("inchikey_canonico", "compostos", "inchikey")],
        "colunas": [
            ("inchikey_origem", T, "InChIKey como veio"),
            ("inchikey_canonico", T, "InChIKey adotado"),
            ("origem", T, "declarado pela base | calculado do SMILES da base"),
            ("bases", T, "bases"),
            ("n_ocorrencias", I, "registros"),
            ("mudou", B, "true = o de origem foi trocado"),
        ],
    },
}

# colunas extras do ADMET-AI (opcional) entram em perfil_admet com o prefixo:
PREFIXO_ADMET_AI = "admetai_"

TIPOS_CONFLITO = {
    "inchikey_declarado_x_smiles": "o InChIKey que a base declara não é o do SMILES que ela mesma dá",
    "smiles_invalido": "o RDKit não lê o SMILES da base",
    "estrutura_entre_bases": "bases dão estruturas diferentes ao mesmo composto",
    "formula_entre_bases": "fórmula da base diferente da do PubChem",
    "cid_entre_bases": "o CID que a base informa não é o do InChIKey canônico",
    "classificacao_classyfire": "classe ClassyFire do COCONUT diferente da API atual",
    "id_x_estrutura": "o mesmo identificador da base aponta para estruturas diferentes",
    "nome_x_estrutura": "o mesmo nome aponta para esqueletos diferentes em bases diferentes",
    "variantes_estereo": "mesma conectividade, estereoquímica diferente (informativo)",
    "sal_ou_forma_carregada": "o registro é sal/forma carregada da parental (informativo)",
}


def colunas(tabela: str) -> list:
    return [c for c, *_ in TABELAS[tabela]["colunas"]]


def dicionario():
    linhas = []
    for nome, t in TABELAS.items():
        estr = {c: f"{tab}.{ref}" for c, tab, ref in t.get("estrangeiras", [])}
        for c, tipo, desc in t["colunas"]:
            linhas.append({"tabela": f"{nome}.csv", "coluna": c, "tipo": tipo,
                           "chave_primaria": c in t["chave"],
                           "chave_estrangeira": estr.get(c, ""), "descricao": desc})
    return linhas


# Bases de origem (FAIR: proveniência e licença). Os termos de licença mudam
# entre versões de cada base e DEVEM ser confirmados na data da coleta; aqui
# fica o que é de conhecimento geral, com essa ressalva.
FONTES_META = [
    {"nome": "COCONUT", "titulo": "COCONUT – COllection of Open Natural ProdUcts",
     "url": "https://coconut.naturalproducts.net",
     "licenca": "aberta (confirmar CC0/CC-BY na versão usada)"},
    {"nome": "NPASS", "titulo": "NPASS – Natural Product Activity & Species Source",
     "url": "https://bidd.group/NPASS/",
     "licenca": "uso acadêmico (confirmar termos no site)"},
    {"nome": "LOTUS", "titulo": "LOTUS – Natural Products Online (via Wikidata)",
     "url": "https://lotus.naturalproducts.net",
     "licenca": "CC0-1.0 (dados no Wikidata)"},
    {"nome": "DUKE", "titulo": "Dr. Duke's Phytochemical and Ethnobotanical Databases (USDA-ARS)",
     "url": "https://phytochem.nal.usda.gov",
     "licenca": "domínio público (obra do governo dos EUA)"},
    {"nome": "FOODB", "titulo": "FooDB",
     "url": "https://foodb.ca",
     "licenca": "uso livre (confirmar termos no site)"},
    {"nome": "ChEMBL", "titulo": "ChEMBL (EMBL-EBI)",
     "url": "https://www.ebi.ac.uk/chembl/",
     "licenca": "CC-BY-SA-3.0"},
    {"nome": "PubChem", "titulo": "PubChem (NCBI/NLM)",
     "url": "https://pubchem.ncbi.nlm.nih.gov",
     "licenca": "trabalho livre; registros de depositantes podem ter termos próprios"},
    {"nome": "ClassyFire", "titulo": "ClassyFire (Wishart Lab)",
     "url": "http://classyfire.wishartlab.com",
     "licenca": "confirmar termos no site"},
    {"nome": "NPClassifier", "titulo": "NPClassifier (via COCONUT)",
     "url": "https://npclassifier.gnps2.org",
     "licenca": "ver COCONUT"},
]

PALAVRAS_CHAVE = ["produtos naturais", "compostos bioativos", "plantas", "fitoquímica",
                  "quimioinformática", "InChIKey", "ADMET", "drogabilidade", "ClassyFire",
                  "bioprospecção", "Brasil"]


def datapackage(nome="banco_bioativos", versao="3.17", extras: dict | None = None,
                licenca="CC-BY-SA-4.0", criado: str | None = None) -> str:
    recursos = []
    for tab, t in TABELAS.items():
        campos = [{"name": c, "type": tipo, "description": d} for c, tipo, d in t["colunas"]]
        for c in (extras or {}).get(tab, []):
            campos.append({"name": c, "type": "any", "description": "ADMET-AI (opcional)"})
        esquema = {"fields": campos, "primaryKey": t["chave"]}
        if t.get("estrangeiras"):
            esquema["foreignKeys"] = [{"fields": c, "reference": {"resource": tab_ref, "fields": ref}}
                                      for c, tab_ref, ref in t["estrangeiras"]]
        recursos.append({"name": tab, "path": f"{tab}.csv", "profile": "tabular-data-resource",
                         "format": "csv", "encoding": "utf-8-sig", "description": t["descricao"],
                         "schema": esquema})
    licencas = {"CC-BY-SA-4.0": ("Creative Commons Attribution-ShareAlike 4.0 International",
                                 "https://creativecommons.org/licenses/by-sa/4.0/"),
                "CC-BY-4.0": ("Creative Commons Attribution 4.0 International",
                              "https://creativecommons.org/licenses/by/4.0/")}
    titulo_lic, path_lic = licencas.get(licenca, (licenca, ""))
    pacote = {
        "name": nome,
        "id": f"urn:prospeccao-bioativos:{versao}",
        "version": versao,
        "profile": "tabular-data-package",
        "title": "Banco de compostos bioativos de plantas (pipeline de prospecção)",
        "description": "Compostos bioativos de plantas integrados de bases públicas, "
                       "deduplicados por InChIKey canônico, com identidade química, "
                       "proveniência, origem biológica, distribuição, bioatividade, vias, "
                       "espectros, perfil ADMET e conflitos entre bases.",
        "keywords": PALAVRAS_CHAVE,
        "created": criado or "",
        "licenses": [{"name": licenca, "title": titulo_lic, "path": path_lic}] if licenca else [],
        "sources": [{"title": f"{f['titulo']} — licença: {f['licenca']}", "path": f["url"]}
                    for f in FONTES_META],
        "contributors": [{"title": "Projeto de prospecção de plantas e bioativos",
                          "role": "author"}],
        "resources": recursos,
    }
    return json.dumps(pacote, ensure_ascii=False, indent=2)


def proveniencia_md(versao="3.17", licenca="CC-BY-SA-4.0", criado: str | None = None) -> str:
    out = ["# Proveniência e licenças", "",
           f"Banco gerado pelo pipeline de prospecção, versão {versao}"
           + (f", em {criado}" if criado else "") + ".", "",
           "## Licença do banco agregado", "",
           f"**{licenca}** (Creative Commons Attribution-ShareAlike 4.0). Ao redistribuir, "
           "cite as bases de origem (abaixo) e mantenha a mesma licença.", "",
           "> A licença do agregado é limitada pela fonte **mais restritiva** usada. O ChEMBL "
           "é CC-BY-SA; por isso CC-BY-SA-4.0 é a escolha compatível. Se você remover o ChEMBL "
           "(tabela `bioatividade.csv`, linhas com `fonte = ChEMBL`), pode reavaliar para uma "
           "licença menos restritiva.", "",
           "## Como citar", "",
           "Cite este banco **e** cada base de origem efetivamente usada na sua coleta "
           "(ver a coluna `base`/`fonte` nas tabelas e os registros em `fontes.csv`).", "",
           "## Bases de origem", "",
           "| Base | Descrição | Licença (confirmar na data da coleta) | Endereço |",
           "|---|---|---|---|"]
    for f in FONTES_META:
        out.append(f"| {f['nome']} | {f['titulo']} | {f['licenca']} | {f['url']} |")
    out += ["", "## Rastreabilidade", "",
            "Cada registro de cada base está em `fontes.csv` (coluna `base`, `id_na_base`, "
            "`url_registro`, `metodo_identificacao`), e o de-para dos InChIKeys de origem para "
            "o canônico está em `mapa_inchikey.csv`. Os conflitos entre bases, e como foram "
            "resolvidos, estão em `conflitos.csv`.", "",
            "> As licenças acima são de conhecimento geral e **mudam entre versões** de cada "
            "base. Confirme os termos vigentes no site de cada fonte na data em que você "
            "executou o pipeline."]
    return "\n".join(out) + "\n"


def esquema_md(contagens: dict | None = None) -> str:
    contagens = contagens or {}
    out = ["# Esquema do banco de compostos bioativos", "",
           "Arquivos CSV (UTF-8 com BOM) interligados pelo **InChIKey canônico** "
           "(`compostos.inchikey`). Os organismos se ligam pelo `nome_cientifico`. "
           "O mesmo esquema está em `datapackage.json` (Frictionless Data) e em "
           "`dicionario_dados.csv`.", "",
           "**FAIR**: identificador canônico universal (InChIKey) e identificadores "
           "externos padronizados (PubChem CID, ChEMBL, ClassyFire, NPClassifier); formato "
           "aberto; esquema e dicionário legíveis por máquina (`datapackage.json`); "
           "proveniência por registro em `fontes.csv`; licenças e bases de origem em "
           "`PROVENIENCIA_E_LICENCAS.md`.", "", "```mermaid", "erDiagram"]
    for tab, t in TABELAS.items():
        for c, tab_ref, ref in t.get("estrangeiras", []):
            out.append(f"    {tab_ref} ||--o{{ {tab} : \"{c}\"")
    out += ["```", ""]
    for tab, t in TABELAS.items():
        n = contagens.get(tab)
        out += [f"## {tab}.csv" + (f" ({n} linhas)" if n is not None else ""), "",
                t["descricao"], "", f"Chave: `{', '.join(t['chave'])}`"]
        if t.get("estrangeiras"):
            out.append("Referências: " + "; ".join(f"`{c}` → `{tr}.{r}`"
                                                 for c, tr, r in t["estrangeiras"]))
        out += ["", "| Coluna | Tipo | Descrição |", "|---|---|---|"]
        out += [f"| `{c}` | {tipo} | {d} |" for c, tipo, d in t["colunas"]]
        out.append("")
    out += ["## Tipos de conflito", "", "| Tipo | Significado |", "|---|---|"]
    out += [f"| `{k}` | {v} |" for k, v in TIPOS_CONFLITO.items()]
    return "\n".join(out) + "\n"
