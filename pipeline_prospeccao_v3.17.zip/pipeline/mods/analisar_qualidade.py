"""
analisar_qualidade.py  -  ETAPA "qualidade" (v3.17)

OE4  análise de qualidade e cobertura do banco:
  - completude de campos, no total e por base de origem;
  - distribuição do espaço químico (ClassyFire e NPClassifier);
  - cobertura taxonômica dos organismos produtores;
  - sobreposição entre as bases (exclusivos e compartilhados, índice de Jaccard);
  - sinais de viés de curadoria (concentração por base/família/classe, lacunas
    sistemáticas de estrutura, bioatividade e distribuição).

Entrada: a pasta banco/ (etapa "banco").
Saída:   banco/qualidade/  - um CSV por análise e RELATORIO_QUALIDADE.md.
         (não depende de rede; só lê os CSVs já gravados)
"""

import os
import sys

import pandas as pd

import esquema_banco as E
from config_pipeline import gravar_csv

BANCO = "banco"
PASTA = os.path.join(BANCO, "qualidade")


def ler(nome) -> pd.DataFrame:
    caminho = os.path.join(BANCO, f"{nome}.csv")
    if os.path.exists(caminho):
        return pd.read_csv(caminho, dtype=str, keep_default_na=False, na_values=[""])
    return pd.DataFrame()


def pct(a, b) -> float:
    return round(100 * a / b, 1) if b else 0.0


# ---------------------------------------------------------------------------
# 1. completude de campos
# ---------------------------------------------------------------------------
def completude(tabelas: dict) -> pd.DataFrame:
    linhas = []
    for nome, df in tabelas.items():
        if df.empty:
            continue
        for col in df.columns:
            preenchidos = df[col].notna().sum()
            linhas.append({"tabela": nome, "coluna": col, "n_linhas": len(df),
                           "preenchidos": int(preenchidos),
                           "completude_pct": pct(preenchidos, len(df))})
    return pd.DataFrame(linhas)


def completude_por_base(compostos: pd.DataFrame, fontes: pd.DataFrame) -> pd.DataFrame:
    """Para campos-chave da identidade química, a completude dos compostos
    SEGUNDO a base que os trouxe (um composto conta para cada base em que ocorre)."""
    if compostos.empty or fontes.empty:
        return pd.DataFrame()
    campos = ["nome_preferido", "pubchem_cid", "inchi", "smiles_isomerico",
              "formula_molecular", "massa_molecular", "classyfire_superclass",
              "np_classifier_pathway"]
    campos = [c for c in campos if c in compostos.columns]
    base_de_ik = fontes.dropna(subset=["inchikey"]).groupby("inchikey")["base"].agg(
        lambda s: sorted(set(s)))
    comp = compostos.copy()
    comp["_bases"] = comp["inchikey"].map(base_de_ik)
    comp = comp.dropna(subset=["_bases"]).explode("_bases")
    linhas = []
    for base, g in comp.groupby("_bases"):
        linha = {"base": base, "n_compostos": len(g)}
        for c in campos:
            linha[f"{c}_pct"] = pct(g[c].notna().sum(), len(g))
        linhas.append(linha)
    total = {"base": "TOTAL (únicos)", "n_compostos": compostos["inchikey"].nunique()}
    for c in campos:
        total[f"{c}_pct"] = pct(compostos[c].notna().sum(), len(compostos))
    return pd.DataFrame(linhas + [total])


# ---------------------------------------------------------------------------
# 2. espaço químico
# ---------------------------------------------------------------------------
def espaco_quimico(compostos: pd.DataFrame) -> dict:
    saida = {}
    for col, rotulo in [("classyfire_superclass", "classyfire_superclasse"),
                        ("classyfire_class", "classyfire_classe"),
                        ("np_classifier_pathway", "npclassifier_via"),
                        ("np_classifier_superclass", "npclassifier_superclasse")]:
        if col in compostos.columns and compostos[col].notna().any():
            cont = compostos[col].value_counts(dropna=True)
            df = cont.rename_axis(rotulo).reset_index(name="n_compostos")
            df["pct"] = df["n_compostos"].map(lambda x: pct(x, len(compostos)))
            saida[rotulo] = df
    return saida


# ---------------------------------------------------------------------------
# 3. cobertura taxonômica
# ---------------------------------------------------------------------------
def cobertura_taxonomica(organismos: pd.DataFrame, origem: pd.DataFrame) -> dict:
    saida = {}
    if organismos.empty:
        return saida
    for col, rotulo in [("familia", "familia"), ("ordem", "ordem"),
                        ("classe", "classe"), ("reino", "reino")]:
        if col in organismos.columns and organismos[col].notna().any():
            g = organismos.groupby(col).agg(
                n_organismos=("nome_cientifico", "nunique")).reset_index()
            if not origem.empty and "inchikey" in origem.columns:
                mapa_tax = organismos.set_index("nome_cientifico")[col]
                comp_por = origem[["nome_cientifico", "inchikey"]].copy()
                comp_por["_tax"] = comp_por["nome_cientifico"].map(mapa_tax)
                n_comp = comp_por.groupby("_tax")["inchikey"].nunique()
                g["n_compostos"] = g[col].map(n_comp).fillna(0).astype(int)
            g = g.sort_values("n_organismos", ascending=False)
            saida[f"taxonomia_{rotulo}"] = g
    # resumo
    resumo = pd.DataFrame([{
        "organismos_com_composto": len(organismos),
        "familias": organismos["familia"].nunique() if "familia" in organismos else 0,
        "ordens": organismos["ordem"].nunique() if "ordem" in organismos else 0,
        "com_distribuicao_conhecida": (organismos["estados_br"].notna().sum()
                                       if "estados_br" in organismos else 0),
        "nativas_br": (organismos["origem_br"].astype(str).str.contains("nativa", case=False).sum()
                       if "origem_br" in organismos else 0),
        "endemicas_br": (organismos["endemismo_br"].astype(str).str.contains("endêmica", case=False,
                         na=False).sum() if "endemismo_br" in organismos else 0)}])
    saida["taxonomia_resumo"] = resumo
    return saida


# ---------------------------------------------------------------------------
# 4. sobreposição entre bases
# ---------------------------------------------------------------------------
def sobreposicao(fontes: pd.DataFrame) -> dict:
    if fontes.empty or "inchikey" not in fontes.columns:
        return {}
    f = fontes.dropna(subset=["inchikey"])
    por_base = {b: set(g["inchikey"]) for b, g in f.groupby("base")}
    bases = sorted(por_base)

    # exclusivos x compartilhados
    conta = f.groupby("inchikey")["base"].nunique()
    linhas = []
    for b in bases:
        iks = por_base[b]
        exclusivos = sum(1 for ik in iks if conta.get(ik, 0) == 1)
        linhas.append({"base": b, "compostos": len(iks), "exclusivos": exclusivos,
                       "exclusivos_pct": pct(exclusivos, len(iks)),
                       "compartilhados": len(iks) - exclusivos})
    resumo = pd.DataFrame(linhas)

    # matriz de Jaccard entre pares de bases
    mat = []
    for a in bases:
        linha = {"base": a}
        for c in bases:
            inter = len(por_base[a] & por_base[c])
            uniao = len(por_base[a] | por_base[c])
            linha[c] = round(inter / uniao, 3) if uniao else 0.0
        mat.append(linha)
    matriz = pd.DataFrame(mat)

    # distribuição do nº de bases por composto
    dist = conta.value_counts().sort_index().rename_axis("n_bases").reset_index(name="n_compostos")
    return {"sobreposicao_bases": resumo, "sobreposicao_jaccard": matriz,
            "compostos_por_n_bases": dist}


# ---------------------------------------------------------------------------
# 5. vieses de curadoria
# ---------------------------------------------------------------------------
def vieses(compostos, fontes, organismos, origem, bioat) -> pd.DataFrame:
    alertas = []

    def add(dim, descricao, metrica, valor):
        alertas.append({"dimensao": dim, "observacao": descricao,
                        "metrica": metrica, "valor": valor})

    n = len(compostos)
    # concentração por base
    if not fontes.empty:
        base_cont = fontes.dropna(subset=["inchikey"]).groupby("base")["inchikey"].nunique()
        if not base_cont.empty:
            dom = base_cont.idxmax()
            add("fonte", f"base que mais contribui: {dom}", "fração dos compostos",
                f"{pct(base_cont.max(), n)}%")
            so_uma = (fontes.dropna(subset=['inchikey']).groupby('inchikey')['base'].nunique() == 1).sum()
            add("fonte", "compostos registrados em uma única base", "fração",
                f"{pct(so_uma, n)}%")

    # lacunas de estrutura / identificadores
    for col, rotulo in [("smiles_isomerico", "sem SMILES"),
                        ("pubchem_cid", "sem PubChem CID"),
                        ("classyfire_superclass", "sem classe ClassyFire")]:
        if col in compostos.columns:
            falta = compostos[col].isna().sum()
            add("completude", f"compostos {rotulo}", "fração", f"{pct(falta, n)}%")

    # concentração do espaço químico
    if "classyfire_superclass" in compostos.columns and compostos["classyfire_superclass"].notna().any():
        top = compostos["classyfire_superclass"].value_counts(normalize=True)
        add("espaço químico", f"superclasse ClassyFire mais frequente: {top.index[0]}",
            "fração dos classificados", f"{round(100 * top.iloc[0], 1)}%")

    # concentração taxonômica
    if not organismos.empty and "familia" in organismos.columns and organismos["familia"].notna().any():
        topf = organismos["familia"].value_counts(normalize=True)
        add("taxonomia", f"família com mais organismos: {topf.index[0]}",
            "fração dos organismos", f"{round(100 * topf.iloc[0], 1)}%")
    if not origem.empty:
        por_org = origem.groupby("nome_cientifico")["inchikey"].nunique()
        if not por_org.empty:
            add("taxonomia", f"organismo com mais compostos: {por_org.idxmax()}",
                "compostos", str(int(por_org.max())))

    # lacuna de bioatividade e de distribuição
    if not bioat.empty:
        com_bio = bioat["inchikey"].nunique()
        add("bioatividade", "compostos sem nenhum registro de bioatividade", "fração",
            f"{pct(n - com_bio, n)}%")
        quant = bioat[bioat["natureza"] == "quantitativa"]["inchikey"].nunique()
        add("bioatividade", "compostos com bioatividade quantitativa", "fração",
            f"{pct(quant, n)}%")
    else:
        add("bioatividade", "nenhum registro de bioatividade no banco", "fração", "100% sem")
    if not organismos.empty and "estados_br" in organismos.columns:
        sem_dist = organismos["estados_br"].isna().sum()
        add("distribuição", "organismos sem distribuição por UF conhecida", "fração",
            f"{pct(sem_dist, len(organismos))}%")

    return pd.DataFrame(alertas)


# ---------------------------------------------------------------------------
# relatório
# ---------------------------------------------------------------------------
def relatorio_md(contagens, comp_base, espaco, taxon, sobrep, viesc) -> str:
    out = ["# Relatório de qualidade e cobertura do banco", "",
           "Análise automática das tabelas de `banco/` (etapa `qualidade`). "
           "As tabelas completas estão nos CSVs desta pasta.", "",
           "## Tamanho das tabelas", "", "| Tabela | Linhas |", "|---|---|"]
    out += [f"| {k} | {v} |" for k, v in contagens.items()]

    if not viesc.empty:
        out += ["", "## Sinais de viés de curadoria", "",
                "| Dimensão | Observação | Métrica | Valor |", "|---|---|---|---|"]
        out += [f"| {r['dimensao']} | {r['observacao']} | {r['metrica']} | {r['valor']} |"
                for _, r in viesc.iterrows()]

    if comp_base is not None and not comp_base.empty:
        out += ["", "## Completude por base (campos da identidade química)", "",
                "Percentual de compostos de cada base com o campo preenchido.", ""]
        out += [tabela_md(comp_base)]

    if "sobreposicao_bases" in sobrep:
        out += ["", "## Sobreposição entre as bases", "",
                "Compostos exclusivos de cada base e compartilhados com outras.", "",
                tabela_md(sobrep["sobreposicao_bases"]), "",
                "Índice de Jaccard entre pares de bases (interseção / união de InChIKeys):", "",
                tabela_md(sobrep["sobreposicao_jaccard"])]

    for rotulo, df in espaco.items():
        out += ["", f"## Espaço químico: {rotulo} (top 15)", "",
                tabela_md(df.head(15))]

    if "taxonomia_resumo" in taxon:
        out += ["", "## Cobertura taxonômica", "", tabela_md(taxon["taxonomia_resumo"])]
        if "taxonomia_familia" in taxon:
            out += ["", "### Famílias com mais organismos (top 15)", "",
                    tabela_md(taxon["taxonomia_familia"].head(15))]
    return "\n".join(out) + "\n"


def tabela_md(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    linhas = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for _, r in df.iterrows():
        linhas.append("| " + " | ".join("" if pd.isna(r[c]) else str(r[c]) for c in cols) + " |")
    return "\n".join(linhas)


def main():
    if not os.path.isdir(BANCO):
        sys.exit(f"Pasta {BANCO}/ não encontrada. Rode a etapa 'banco' primeiro.")
    nomes = list(E.TABELAS)
    tabelas = {n: ler(n) for n in nomes}
    compostos = tabelas["compostos"]
    os.makedirs(PASTA, exist_ok=True)
    if compostos.empty:
        # banco vazio: grava um relatório mínimo e o marcador, sem falhar a etapa
        gravar_csv(completude(tabelas), os.path.join(PASTA, "completude_campos.csv"))
        with open(os.path.join(PASTA, "RELATORIO_QUALIDADE.md"), "w", encoding="utf-8") as f:
            f.write("# Relatório de qualidade\n\nO banco não tem compostos: nada a analisar.\n")
        print("Banco vazio: nada a analisar.")
        return
    fontes = tabelas["fontes"]
    organismos = tabelas["organismos"]
    origem = tabelas["origem_biologica"]
    bioat = tabelas["bioatividade"]
    print(f"Analisando banco/ ({len(compostos)} compostos, {len(fontes)} registros de fonte)")

    os.makedirs(PASTA, exist_ok=True)
    contagens = {n: len(df) for n, df in tabelas.items()}

    print("1. Completude de campos")
    comp_geral = completude(tabelas)
    comp_base = completude_por_base(compostos, fontes)

    print("2. Espaço químico")
    espaco = espaco_quimico(compostos)

    print("3. Cobertura taxonômica")
    taxon = cobertura_taxonomica(organismos, origem)

    print("4. Sobreposição entre bases")
    sobrep = sobreposicao(fontes)

    print("5. Vieses de curadoria")
    viesc = vieses(compostos, fontes, organismos, origem, bioat)

    gravar_csv(comp_geral, os.path.join(PASTA, "completude_campos.csv"))
    if comp_base is not None and not comp_base.empty:
        gravar_csv(comp_base, os.path.join(PASTA, "completude_por_base.csv"))
    for rotulo, df in espaco.items():
        gravar_csv(df, os.path.join(PASTA, f"espaco_quimico_{rotulo}.csv"))
    for rotulo, df in taxon.items():
        gravar_csv(df, os.path.join(PASTA, f"{rotulo}.csv"))
    for rotulo, df in sobrep.items():
        gravar_csv(df, os.path.join(PASTA, f"{rotulo}.csv"))
    gravar_csv(viesc, os.path.join(PASTA, "vieses_curadoria.csv"))

    with open(os.path.join(PASTA, "RELATORIO_QUALIDADE.md"), "w", encoding="utf-8") as f:
        f.write(relatorio_md(contagens, comp_base, espaco, taxon, sobrep, viesc))

    print(f"\nConcluído: banco/qualidade/ com {len(espaco) + len(taxon) + len(sobrep) + 3} "
          "planilha(s) e RELATORIO_QUALIDADE.md")
    if not viesc.empty:
        print("  Sinais de viés (resumo):")
        for _, r in viesc.iterrows():
            print(f"    [{r['dimensao']}] {r['observacao']}: {r['valor']}")


if __name__ == "__main__":
    main()
